# ml-recommender
1) unzip the zip file, u will find csv files put them in the main directory and delete rest of the folder
2) run the flask app
3) input will be as: "text"="The Avengers"
4) POST request
